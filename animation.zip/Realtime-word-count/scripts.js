const typeTextEl = document.querySelector("#textarea");
const totalTextEl = document.querySelector(".total-counter");
const remainingTextEl = document.querySelector(".remaining-counter");

typeTextEl.addEventListener("keyup", () => {
    realTimeText();
});
realTimeText();

function realTimeText() {
    const textCount = typeTextEl.value.length;
    if (textCount < 10) {
        totalTextEl.innerText = "0" + textCount;
    } else {
        totalTextEl.innerText = textCount;
    }
    remainingTextEl.innerText = typeTextEl.getAttribute("maxlength") - textCount;
}