calendarUpdate();
function calendarUpdate() {
    const monthNameEl = document.getElementById("month-name");
    const dayNameEl = document.getElementById("day-name");
    const dayNumEl = document.getElementById("day-number");
    const yearEl = document.getElementById("year");
    const hourEl = document.getElementById("hour");
    const minuteEl = document.getElementById("minute");
    const secondEl = document.getElementById("second");

    const date = new Date();
    const month = date.getMonth();
    monthNameEl.innerText = date.toLocaleString("en", { month: "long" });
    dayNameEl.innerText = date.toLocaleString("en", { weekday: "long" });
    dayNumEl.innerText = date.getDate();
    yearEl.innerText = date.getFullYear();
    hourEl.innerText = date.getHours();
    minuteEl.innerText = date.getMinutes();
    secondEl.innerText = date.getSeconds();


    setTimeout(calendarUpdate, 3);
}
