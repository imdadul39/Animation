const containerEl = document.querySelector('.container');

const careers = ["Youtuber", "Web Developer", "Freelancer", "Instructor"];
let careerindex = 0;
let characterIndex = 0;

function updateText() {
    characterIndex++;
    containerEl.innerHTML = `
        <h1>I am ${careers[careerindex].slice(0, 1) === "I" ? "an" : "a"} ${careers[careerindex].slice(0, characterIndex)}</h1>
    `;
    if (characterIndex === careers[careerindex].length) {
        careerindex++;
        characterIndex = 0;
    }
    if (careerindex ===careers.length) {
        careerindex = 0;
    }

    setTimeout(updateText, 300);
}
updateText();