const containerEl = document.querySelector(".container");

for (let index = 0; index < 30; index++) {
    const conlorContainerEl = document.createElement('div');
    conlorContainerEl.classList.add("color-contianer");
    containerEl.appendChild(conlorContainerEl);
}

const containerEls = document.querySelectorAll(".color-contianer");
generateColors();
function generateColors() {
    containerEls.forEach((conlorContainerEl) => {
        const newColor = randomColor();
        conlorContainerEl.style.backgroundColor = "#" + newColor;
        conlorContainerEl.innerText = "#" + newColor;
    });
}



function randomColor() {
    const chars = "123456789abcdef";
    const colorCodeLength = 6;
    let colorCode = "";

    for (let index = 0; index < colorCodeLength; index++) {
        const randomNum = Math.floor(Math.random() * chars.length);
        colorCode += chars.substring(randomNum, randomNum + 1);
    }
    return colorCode;
}