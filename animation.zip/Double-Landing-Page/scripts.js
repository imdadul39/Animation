const containerel = document.querySelector(".container");

const leftEl = document.querySelector(".left");
const rightEl = document.querySelector(".right");


leftEl.addEventListener('mouseenter', () => {
    leftEl.style.width = "60%";
    rightEl.style.width = "40%";
});
leftEl.addEventListener('mouseleave', () => {
    leftEl.style.width = "50%";
    rightEl.style.width = "50%";
});

rightEl.addEventListener('mouseenter', () => {
    leftEl.style.width = "40%";
    rightEl.style.width = "60%";
});
rightEl.addEventListener('mouseleave', () => {
    leftEl.style.width = "50%";
    rightEl.style.width = "50%";
});