const searchBarContainerEl = document.querySelector('.search-bar-container');
const bodyEl = document.querySelector('body');
const magnifierEl = document.querySelector('.magnifier');

magnifierEl.addEventListener("click", () => {
    searchBarContainerEl.classList.toggle("active");
});

